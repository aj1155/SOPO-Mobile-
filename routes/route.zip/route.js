var express = require('express');
var router = express.Router();
var passport = require('../join/passport');
var fs = require('fs');

	var	bodyParser = require('body-parser');
  var	formidable = require('formidable');
	var	morgan = require('morgan');
	var multipart = require('connect-multiparty');
	var multipartMiddleware=multipart();


var connection = require('../join/connection');
router.post('/upload2',multipartMiddleware,function(req,res,next){
	console.log(req.data.file);
	console.log(req.data.userInfo);
  fs.readFile(req.files.uploadFile.path,function(error,data){
    console.log(req.files.uploadFile.name);
    console.log(req.files);
		req.files.uploadFile.name = "2012.gif";
  var p_user = {

        image:req.files.uploadFile.name
      };


      var filePath=__dirname+"/../public/images/"+req.files.uploadFile.name;
      fs.writeFile(filePath,data,function(error){
        if(error){
          throw error;
        }else{
          console.log("성공");
        }



});
});
});
router.post('/upload',multipartMiddleware,function(req,res,next){
  fs.readFile(req.files.uploadFile.path,function(error,data){
    console.log(req.files.uploadFile.name);
    console.log(req.files);
		req.files.uploadFile.name = "2012.gif";
  var p_user = {

        image:req.files.uploadFile.name
      };


      var filePath=__dirname+"/../public/images/"+req.files.uploadFile.name;
      fs.writeFile(filePath,data,function(error){
        if(error){
          throw error;
        }else{
          console.log("성공");
        }



});
});
});

router.get('/get_userList',function(req,res){
    connection.query('SELECT * FROM students order by id',function(error,result){
      if(error){
        res.send(error);

      }
      console.log(result);
      res.json(result);
    });
});


router.post('/regist_User',function(req,res,next){
	connection.query('INSERT INTO users SET ?' ,[req.body],function(err,results){
        console.log(results);
        var data = {
          result : "success"
        };
		    				if(err){
		    					next(err);
		    				}
                else{
                  res.json(data);
                }


		    		});


});

router.post('/login_user',passport.authenticate('local',{failureRedirect:'/',failureFlash:true}),
function(req,res){
  console.log("포스트 성공");
  console.log(req.user.id);
  console.log(req.user.password);

  res.json(req.user);



});



module.exports = router;
